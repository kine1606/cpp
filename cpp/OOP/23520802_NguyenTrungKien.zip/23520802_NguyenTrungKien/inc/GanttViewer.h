#include "PlanViewer.h"
class GanttViewer : public PlanViewer
{
public:
    void hienThi() override;
    GanttViewer();
    ~GanttViewer();
};
