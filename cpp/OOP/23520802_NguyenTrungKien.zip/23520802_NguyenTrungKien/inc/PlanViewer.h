#pragma once
class PlanViewer
{
public:
    virtual void hienThi() = 0;
    PlanViewer();
    virtual ~PlanViewer();
};
