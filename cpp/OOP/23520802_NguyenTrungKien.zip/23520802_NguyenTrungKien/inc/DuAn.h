#pragma once
#include "CongViec.h"
#include "PlanViewer.h"
#include "Exporter.h"
#include <string>
class DuAn
{
private:
    CongViec* m_danhSachCongViec[50];
    int m_soLuongCongViec;
    std::string m_maDuAn;
    std::string m_ten;
    std::string m_moTa;
    std::string m_thongTinNguoiQuanTri;
    Exporter* m_luuTru;
    PlanViewer* m_hienThi;
public:
    DuAn();
    void input();
    void setLuuTru(int);
    std::string getMaSo();
    void output();
    ~DuAn();
};

