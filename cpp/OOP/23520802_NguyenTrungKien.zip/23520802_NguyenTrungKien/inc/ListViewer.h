#include "PlanViewer.h"
class ListViewer : public PlanViewer
{
public:
    void hienThi() override;
    ListViewer();
    ~ListViewer();
};
