#include "DuAn.h"
#pragma once
class Exporter
{
public:
    virtual void xuatFile(DuAn*);
    Exporter();
    virtual ~Exporter();
};