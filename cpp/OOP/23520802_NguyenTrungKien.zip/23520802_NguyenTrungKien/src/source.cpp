#include "../inc/QuanTriCongViec.h"
int main()
{
    QuanTriCongViec ds;
    ds.input();
    ds.output();
}