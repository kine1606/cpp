#include "../inc/ListViewer.h"
#include <iostream>
ListViewer::ListViewer() = default;
void ListViewer::hienThi()
{
    std::cout<< "ListViewer" <<'\n';
}
ListViewer::~ListViewer(){}