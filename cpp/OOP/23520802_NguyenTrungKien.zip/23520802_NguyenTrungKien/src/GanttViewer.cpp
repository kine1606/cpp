#include "../inc/GanttViewer.h"
#include <iostream>
GanttViewer::GanttViewer() = default;
void GanttViewer::hienThi()
{
    std::cout<< "GanttChartViewer" <<'\n';
}
GanttViewer::~GanttViewer(){}