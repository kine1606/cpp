#include "../inc/Exporter.h"
#include "../inc/DuAn.h"
Exporter::Exporter() = default;
void xuatFile(DuAn* x)
{
    return;
}
Exporter::~Exporter(){}