#pragma once
#include "Ve.h"
class VeKhachQuen : public Ve
{
public:
    VeKhachQuen();
    void input() override;
    int getType() override;
    
};
