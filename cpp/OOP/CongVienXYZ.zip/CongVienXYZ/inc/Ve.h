#pragma once

class Ve
{
protected:
    int m_giaVe;
    int m_soTroChoi;
public:
    Ve();
    virtual void input();
    virtual int getType();
    int getGia();
    friend class CongVien;
};
